﻿namespace Key_Value_Store
{
    static class Program
    {
        static void Main(string[] args)
        {
            App app = new App();

        }
    }
}